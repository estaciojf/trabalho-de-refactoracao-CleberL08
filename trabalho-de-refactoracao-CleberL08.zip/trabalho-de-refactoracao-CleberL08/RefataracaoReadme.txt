Nome: Cleber Lucas Moreira do Nascimento Matricula: 201802094377


Nome:Luan Rocha Ladeira Prazeres 
Matricula:201803154731


Refatoração código LivroLocadora:



---------Magic Numbers---------

No arquivo CadastroLivroCotroller, foi implementado a tecnica Magic Numbers para que nao haja numeros no "for" (line 51) transformando assim em uma constante chamada "YEAR" e atribuindo a ela o valor que antes se encontrava no meio do "for"


-------------Enum-------------

No arquivo LivroDAO, foi alterado na query (line 75) o nome "Livro" para LivroDAO.table, assim caso seja necessário a troca do nome de "Livro" para outro nome, não precisará dar a manutenção da query, trazendo assim mais simplicidade ao código, e fazendo com que nao haja erros com grande facilidade
