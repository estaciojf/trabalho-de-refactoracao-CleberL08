module LivroLocadora {
	requires java.desktop;
	requires java.naming;
	requires jdk.jdi;
	requires java.sql;
}