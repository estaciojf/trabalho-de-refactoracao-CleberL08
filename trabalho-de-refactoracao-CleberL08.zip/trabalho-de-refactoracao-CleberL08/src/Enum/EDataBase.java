package Enum;

public abstract class EDataBase {

	public static final String DB_USER = "root";
	public static final String DB_PASS = "yami";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/locadora";
}
